package enums;

public enum CustomerStatusEnum {
	APPROVED, 
	NOT_APPROVED
}
