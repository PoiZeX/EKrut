package enums;

public enum DeliveryStatusEnum {
	pendingApproval,
	outForDelivery,
	done
}
