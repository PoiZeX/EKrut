package interfaces;


/**
 * Interface for all screens
 *
 */
public interface IScreen {
	public void initialize(); /** Method to implements for initialization */
}
