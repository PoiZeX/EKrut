package interfaces;


/***
 * interface that has a setup table 
 * and a setup for a comb box
 * @author User
 *
 */
public interface ICmbANDTableSetUp extends IScreen {
	void setupTable(int id);
	void setUpComboBox();
}
