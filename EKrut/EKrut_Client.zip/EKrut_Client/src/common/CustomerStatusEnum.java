package common;

public enum CustomerStatusEnum {
	APPROVED, 
	NOT_APPROVED
}
