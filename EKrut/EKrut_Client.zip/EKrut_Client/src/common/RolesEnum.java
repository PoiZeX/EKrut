package common;

public enum RolesEnum {
	user,  // from simulation
	registered, 
	member,
	customerServiceWorker,
	marketingWorker,
	marketingManager,
	supplyWorker,
	supplyManager, 
	regionManager,
	CEO, 
	deliveryOperator,
	

}
