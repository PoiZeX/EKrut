package common;

public enum DeliveryStatusEnum {
	pendingApproval,
	outForDelivery,
	done
}
