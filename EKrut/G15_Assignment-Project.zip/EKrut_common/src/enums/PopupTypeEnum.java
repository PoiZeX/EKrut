package enums;

public enum PopupTypeEnum {
	Error,
	Success,
	Warning,
	Information,
	Decision,
	Sale,
	Simulation 
}
